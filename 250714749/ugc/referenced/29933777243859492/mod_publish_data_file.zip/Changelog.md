# Changelog

## [1.0.4.2] U54-646843-SCR (release)
- removed ID safeguard

## [1.0.4.1] U52-626616-SC (release)
- fix for buildings with underscore #68

## [1.0.4.0] U45-546664-S
- new default recipe

## [1.0.3.0] U44-535842-S
- fixed buildings so they don't force store outputs (affects GlassForge and UraniumCentrifuge)
- recipes with missing storeElement property will default to true, if the element is liquid
- added new setting HEPout (only for buildings that can produce them)

## [1.0.2.0] U41-498381-S
- added sanity checks

## [1.0.1.0] U34-476542-S
- initial release
