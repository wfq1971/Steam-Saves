# Changelog

## [1.0.10.0] U56-675600-SCRP (release)
- added fields NameDisplay, CustomName, CustomSpritePrefabID

## [1.0.9.0] U56-674504-SCRP (release)
- added support for multi ingredient inputs
- fixed recipe printout

## [1.0.8.0] U56-674504-SCRP (release)
- nevermind, does not fix it

## [1.0.7.0] U56-674504-SCRP (release)
- fixed custom recipe not being added

## [1.0.6.0] U56-674504-SCR (release)
- fixed crash with new update

## [1.0.5.0] U55-661174-SCR (release)
- ensured description field is not null

## [1.0.4.2] U54-646843-SCR (release)
- removed ID safeguard

## [1.0.4.1] U52-626616-SC (release)
- fix for buildings with underscore #68

## [1.0.4.0] U45-546664-S
- new default recipe

## [1.0.3.0] U44-535842-S
- fixed buildings so they don't force store outputs (affects GlassForge and UraniumCentrifuge)
- recipes with missing storeElement property will default to true, if the element is liquid
- added new setting HEPout (only for buildings that can produce them)

## [1.0.2.0] U41-498381-S
- added sanity checks

## [1.0.1.0] U34-476542-S
- initial release
